package runtime

//go:generate go run gen/main.go

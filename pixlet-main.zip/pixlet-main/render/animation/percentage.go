package animation

type Percentage struct {
	Value float64
}

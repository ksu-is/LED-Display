#!/bin/bash

set -e

brew install \
    webp \
    gnupg
#!/bin/bash

export LIBWEBP_VERSION="libwebp-1.2.2-rc1"
